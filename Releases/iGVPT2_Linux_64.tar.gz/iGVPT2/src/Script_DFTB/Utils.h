#ifndef UTILS_H
#define UTILS_H

using namespace std;
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstdio>
#include <unistd.h>
#include <cmath>
#include <cstring>
#include <cstdlib>
#include <cassert>
#include <cstdarg>
#include <vector>

vector<string> split(string str);
char *getSuffixNameFile(const char* allname);
#endif /* UTILS_H*/
